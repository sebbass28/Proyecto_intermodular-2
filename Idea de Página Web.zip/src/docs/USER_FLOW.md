# FinanceFlow - Flujo de Usuario Completo

## 🎯 JOURNEY DEL USUARIO

```
┌─────────────┐
│   INICIO    │
│  (Landing)  │
└──────┬──────┘
       │
       ├─────────────┐
       │             │
       ▼             ▼
┌──────────┐   ┌──────────┐
│  LOGIN   │   │ REGISTRO │
└────┬─────┘   └────┬─────┘
     │              │
     └──────┬───────┘
            │
            ▼
     ┌──────────────┐
     │  DASHBOARD   │ ◄─── Página Principal
     │  (Principal) │
     └──────┬───────┘
            │
       ┌────┴────┬────────┬────────┬────────┬────────┬────────┐
       │         │        │        │        │        │        │
       ▼         ▼        ▼        ▼        ▼        ▼        ▼
   ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐
   │Trans│  │Presu│  │Carte│  │Inver│  │Metas│  │Repor│  │Perfil│
   │acc. │  │puest│  │ras  │  │sione│  │     │  │tes  │  │      │
   └─────┘  └─────┘  └─────┘  └─────┘  └─────┘  └─────┘  └─────┘
```

---

## 1️⃣ FLUJO DE REGISTRO E INICIO DE SESIÓN

### Nuevo Usuario
```
┌─────────────────────────────────────────────────────────────┐
│ 1. LANDING / LOGIN                                          │
│    Usuario ve la página de login                           │
│    ↓                                                        │
│    Click en "Regístrate aquí"                              │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ 2. FORMULARIO DE REGISTRO                                   │
│    ┌──────────────────────────────────┐                    │
│    │ Nombre: [Juan Pérez           ] │                    │
│    │ Email:  [juan@email.com       ] │                    │
│    │ Pass:   [••••••••             ] │                    │
│    │ Conf:   [••••••••             ] │                    │
│    │ [✓] Acepto términos             │                    │
│    │                                  │                    │
│    │      [CREAR CUENTA]              │                    │
│    └──────────────────────────────────┘                    │
│                                                             │
│    Validaciones:                                            │
│    ✓ Email válido                                          │
│    ✓ Contraseña > 6 caracteres                            │
│    ✓ Contraseñas coinciden                                │
│    ✓ Términos aceptados                                   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ 3. CREACIÓN DE CUENTA                                       │
│    ⏳ Enviando datos...                                    │
│    → POST /signup                                           │
│    → Supabase crea usuario                                 │
│    → Auto-confirma email                                   │
│    ✅ Cuenta creada                                        │
│    🔑 Token generado                                       │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ 4. AUTO-LOGIN                                               │
│    → AuthContext actualizado                               │
│    → isAuthenticated = true                                │
│    → user = { name, email }                                │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ 5. BIENVENIDA                                               │
│    🎉 Toast: "¡Bienvenido a FinanceFlow!"                  │
│    → Redirect a Dashboard                                  │
│    → Tutorial inicial (opcional)                           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Usuario Existente
```
┌─────────────────────────────────────────────────────────────┐
│ 1. LOGIN                                                    │
│    ┌──────────────────────────────────┐                    │
│    │ Email: [juan@email.com        ] │                    │
│    │ Pass:  [••••••••              ] │                    │
│    │ [✓] Recordarme                  │                    │
│    │                                  │                    │
│    │      [INICIAR SESIÓN]            │                    │
│    │                                  │                    │
│    │  ── o continuar con ──           │                    │
│    │  [🔵 Google]                     │                    │
│    └──────────────────────────────────┘                    │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ 2. AUTENTICACIÓN                                            │
│    → supabase.auth.signInWithPassword()                    │
│    → Valida credenciales                                   │
│    → Genera access_token                                   │
│    ✅ Login exitoso                                        │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ 3. CARGAR SESIÓN                                            │
│    → Obtiene datos del usuario                             │
│    → Carga preferencias                                    │
│    → AuthContext actualizado                               │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ 4. DASHBOARD                                                │
│    ✅ "¡Bienvenido de vuelta, Juan!"                       │
│    → Muestra dashboard con datos                           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 2️⃣ FLUJO DE TRANSACCIONES

### Crear Nueva Transacción
```
┌─────────────────────────────────────────────────────────────┐
│ DESDE CUALQUIER PÁGINA                                      │
│                                                             │
│ [+ Nueva Transacción] ◄── Click en sidebar                │
│          │                                                  │
│          ▼                                                  │
│ ┌────────────────────────────────────┐                     │
│ │ 💰 Nueva Transacción          [✕] │                     │
│ ├────────────────────────────────────┤                     │
│ │                                    │                     │
│ │ Paso 1: Seleccionar tipo           │                     │
│ │ ┌─────────┐  ┌─────────┐          │                     │
│ │ │ 💸 Gasto│  │💰 Ingreso│          │                     │
│ │ │  [•]    │  │  [ ]     │          │                     │
│ │ └─────────┘  └─────────┘          │                     │
│ │                                    │                     │
│ │ Paso 2: Ingresar monto             │                     │
│ │ Monto: [$ 150.00          ]        │                     │
│ │                                    │                     │
│ │ Paso 3: Categoría                  │                     │
│ │ [🍔 Comida             ▾]          │                     │
│ │                                    │                     │
│ │ Paso 4: Detalles (opcional)        │                     │
│ │ Descripción:                        │                     │
│ │ [Almuerzo con cliente   ]          │                     │
│ │                                    │                     │
│ │ Fecha: [2024-03-15     ]           │                     │
│ │                                    │                     │
│ │ [Cancelar] [Crear Transacción]     │                     │
│ └────────────────────────────────────┘                     │
│          │                                                  │
│          ▼                                                  │
│ Validación:                                                 │
│ ✓ Monto > 0                                                │
│ ✓ Categoría seleccionada                                  │
│ ✓ Fecha válida                                            │
│          │                                                  │
│          ▼                                                  │
│ [Crear Transacción] ◄── Click                             │
│          │                                                  │
│          ▼                                                  │
│ ⏳ Guardando...                                            │
│ → POST /transactions                                        │
│ → { type: 'expense', amount: -150, ... }                   │
│          │                                                  │
│          ▼                                                  │
│ ✅ Transacción creada                                      │
│ 🔔 Toast: "Transacción creada exitosamente"               │
│ → Modal se cierra                                          │
│ → Lista actualizada                                        │
│ → Dashboard actualizado (si está ahí)                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Ver y Filtrar Transacciones
```
┌─────────────────────────────────────────────────────────────┐
│ PÁGINA DE TRANSACCIONES                                     │
│                                                             │
│ Transacciones                    [+ Nueva Transacción]     │
│ ───────────────────────────────────────────────────────────│
│                                                             │
│ [🔍 Buscar] [📅 Fecha▾] [📁 Categoría▾] [💰 Tipo▾]       │
│                                                             │
│ Acciones del usuario:                                       │
│                                                             │
│ 1. BUSCAR                                                   │
│    Usuario escribe: "almuerzo"                             │
│    → Filtra en tiempo real                                 │
│    → Muestra resultados que coinciden                      │
│                                                             │
│ 2. FILTRAR POR FECHA                                        │
│    Click en [📅 Fecha▾]                                    │
│    → Despliega opciones:                                   │
│      • Hoy                                                 │
│      • Esta semana                                         │
│      • Este mes                                            │
│      • Personalizado                                       │
│    → Actualiza lista                                       │
│                                                             │
│ 3. FILTRAR POR CATEGORÍA                                    │
│    Click en [📁 Categoría▾]                                │
│    → Muestra categorías:                                   │
│      🍔 Comida                                             │
│      🚗 Transporte                                         │
│      🎬 Entretenimiento                                    │
│      ...                                                   │
│    → Filtra por selección                                 │
│                                                             │
│ 4. EDITAR TRANSACCIÓN                                       │
│    Hover sobre fila                                        │
│    → Aparece [✏️] [🗑️]                                    │
│    Click en [✏️]                                           │
│    → Abre modal con datos                                 │
│    → Modifica y guarda                                    │
│                                                             │
│ 5. ELIMINAR TRANSACCIÓN                                     │
│    Click en [🗑️]                                          │
│    → Confirmar: "¿Estás seguro?"                          │
│    → DELETE /transactions/:id                              │
│    ✅ Eliminada                                            │
│                                                             │
│ 6. PAGINACIÓN                                               │
│    Scroll hasta el final                                   │
│    → Click [Siguiente →]                                   │
│    → Carga más transacciones                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 3️⃣ FLUJO DE PRESUPUESTOS

### Crear Presupuesto
```
┌─────────────────────────────────────────────────────────────┐
│ PÁGINA DE PRESUPUESTOS                                      │
│                                                             │
│ Usuario: "Quiero controlar mis gastos de comida"           │
│                                                             │
│ [+ Nuevo Presupuesto] ◄── Click                            │
│          │                                                  │
│          ▼                                                  │
│ ┌────────────────────────────────────┐                     │
│ │ 💰 Nuevo Presupuesto          [✕] │                     │
│ ├────────────────────────────────────┤                     │
│ │                                    │                     │
│ │ Categoría: [🍔 Comida       ▾]    │                     │
│ │                                    │                     │
│ │ Límite: [$ 500.00           ]      │                     │
│ │                                    │                     │
│ │ Periodo: [○ Mensual  ○ Anual]     │                     │
│ │                                    │                     │
│ │ Alertas:                           │                     │
│ │ [✓] Al 80% del límite              │                     │
│ │ [✓] Al 100% del límite             │                     │
│ │                                    │                     │
│ │ [Cancelar] [Crear Presupuesto]     │                     │
│ └────────────────────────────────────┘                     │
│          │                                                  │
│          ▼                                                  │
│ ⏳ Creando...                                              │
│ → POST /budgets                                            │
│          │                                                  │
│          ▼                                                  │
│ ✅ Presupuesto creado                                      │
│ → Aparece en la lista                                      │
│                                                             │
│ ┌─────────────────────────────────────┐                    │
│ │ 🍔 Comida              [Editar] [✕]│                    │
│ │                                     │                    │
│ │ $0 de $500                     0%   │                    │
│ │ [░░░░░░░░░░░░░░░░░░░░]             │                    │
│ │                                     │                    │
│ │ Quedan: $500 | 30 días restantes    │                    │
│ └─────────────────────────────────────┘                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Seguimiento del Presupuesto
```
┌─────────────────────────────────────────────────────────────┐
│ DURANTE EL MES                                              │
│                                                             │
│ Día 1: Usuario crea transacción de Comida por $50          │
│ → Sistema actualiza presupuesto automáticamente            │
│                                                             │
│ ┌─────────────────────────────────────┐                    │
│ │ 🍔 Comida                           │                    │
│ │ $50 de $500                    10%  │                    │
│ │ [██░░░░░░░░░░░░░░░░░░]             │                    │
│ │ Quedan: $450 | 29 días              │                    │
│ └─────────────────────────────────────┘                    │
│                                                             │
│ Día 10: Gasta otros $350 (total $400)                      │
│ → 80% alcanzado                                            │
│ 🔔 Alerta: "Presupuesto de Comida al 80%"                 │
│                                                             │
│ ┌─────────────────────────────────────┐                    │
│ │ 🍔 Comida                           │                    │
│ │ $400 de $500                   80%  │                    │
│ │ [████████████████░░░░] ⚠️          │                    │
│ │ Quedan: $100 | 20 días              │                    │
│ └─────────────────────────────────────┘                    │
│                                                             │
│ Día 20: Gasta otros $100 (total $500)                      │
│ → 100% alcanzado                                           │
│ 🔔 Alerta: "¡Presupuesto de Comida agotado!"              │
│                                                             │
│ ┌─────────────────────────────────────┐                    │
│ │ 🍔 Comida                           │                    │
│ │ $500 de $500                  100%  │                    │
│ │ [████████████████████] ⛔          │                    │
│ │ Quedan: $0 | 10 días                │                    │
│ └─────────────────────────────────────┘                    │
│                                                             │
│ Si gasta más:                                               │
│ ┌─────────────────────────────────────┐                    │
│ │ 🍔 Comida                           │                    │
│ │ $550 de $500                  110%  │                    │
│ │ [████████████████████] ⛔ +$50     │                    │
│ │ Excedido por: $50                   │                    │
│ └─────────────────────────────────────┘                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 4️⃣ FLUJO DE METAS

### Crear Meta de Ahorro
```
┌─────────────────────────────────────────────────────────────┐
│ USUARIO QUIERE AHORRAR PARA VACACIONES                      │
│                                                             │
│ [+ Nueva Meta] ◄── Click                                   │
│          │                                                  │
│          ▼                                                  │
│ ┌────────────────────────────────────┐                     │
│ │ 🎯 Nueva Meta                 [✕] │                     │
│ ├────────────────────────────────────┤                     │
│ │                                    │                     │
│ │ Nombre: [Vacaciones en Europa]     │                     │
│ │                                    │                     │
│ │ Monto objetivo: [$ 6,000.00  ]     │                     │
│ │                                    │                     │
│ │ Fecha límite: [2024-06-30    ]     │                     │
│ │                                    │                     │
│ │ Icono: [🏖️ ▾]                      │                     │
│ │                                    │                     │
│ │ Ahorro automático:                 │                     │
│ │ [✓] Apartar $200 cada quincena     │                     │
│ │                                    │                     │
│ │ [Cancelar] [Crear Meta]            │                     │
│ └────────────────────────────────────┘                     │
│          │                                                  │
│          ▼                                                  │
│ ✅ Meta creada                                             │
│                                                             │
│ ┌─────────────────────────────────────┐                    │
│ │ 🏖️ Vacaciones en Europa [Edit] [✕]│                    │
│ │                                     │                    │
│ │ $0 de $6,000                   0%   │                    │
│ │ [░░░░░░░░░░░░░░░░░░░░]             │                    │
│ │                                     │                    │
│ │ Faltan: $6,000 | 3 meses            │                    │
│ │                                     │                    │
│ │ [+ Agregar fondos]                  │                    │
│ └─────────────────────────────────────┘                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Agregar Fondos a Meta
```
┌─────────────────────────────────────────────────────────────┐
│ [+ Agregar fondos] ◄── Click                               │
│          │                                                  │
│          ▼                                                  │
│ ┌────────────────────────────────────┐                     │
│ │ Agregar fondos a:                  │                     │
│ │ 🏖️ Vacaciones en Europa            │                     │
│ │                                    │                     │
│ │ Monto: [$ 1,500.00         ]       │                     │
│ │                                    │                     │
│ │ Desde: [💰 Ahorro          ▾]     │                     │
│ │                                    │                     │
│ │ [Cancelar] [Agregar]               │                     │
│ └────────────────────────────────────┘                     │
│          │                                                  │
│          ▼                                                  │
│ ⏳ Procesando...                                           │
│ → POST /goals/:id/add-funds                                │
│ → Actualiza saldo de meta                                 │
│ → Actualiza saldo de cartera                              │
│          │                                                  │
│          ▼                                                  │
│ ✅ Fondos agregados                                        │
│                                                             │
│ ┌─────────────────────────────────────┐                    │
│ │ 🏖️ Vacaciones en Europa            │                    │
│ │                                     │                    │
│ │ $1,500 de $6,000              25%   │                    │
│ │ [█████░░░░░░░░░░░░░░]              │                    │
│ │                                     │                    │
│ │ Faltan: $4,500 | 3 meses            │                    │
│ │                                     │                    │
│ │ A este ritmo la completarás en 6    │                    │
│ │ meses. ¡Aumenta tus aportes!        │                    │
│ └─────────────────────────────────────┘                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Completar Meta
```
┌─────────────────────────────────────────────────────────────┐
│ Usuario agrega $4,500 más                                   │
│          │                                                  │
│          ▼                                                  │
│ ┌─────────────────────────────────────┐                    │
│ │ 🏖️ Vacaciones en Europa            │                    │
│ │                                     │                    │
│ │ $6,000 de $6,000             100%   │                    │
│ │ [████████████████████] ✅          │                    │
│ │                                     │                    │
│ │ ¡Meta completada!                   │                    │
│ └─────────────────────────────────────┘                    │
│                                                             │
│ 🎉 ¡FELICIDADES!                                           │
│ 🔔 "¡Has completado tu meta de Vacaciones!"                │
│                                                             │
│ Opciones:                                                   │
│ • [Ver metas completadas]                                  │
│ • [Crear nueva meta]                                       │
│ • [Retirar fondos]                                         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 5️⃣ FLUJO DE REPORTES

```
┌─────────────────────────────────────────────────────────────┐
│ PÁGINA DE REPORTES                                          │
│                                                             │
│ Usuario: "Quiero ver cómo he gastado este mes"             │
│                                                             │
│ [📊 Mensual] [📈 Trimestral] [📅 Anual] [🎯 Custom]       │
│      ▲                                                      │
│      │                                                      │
│ Click en [📊 Mensual]                                       │
│          │                                                  │
│          ▼                                                  │
│ Periodo: [Marzo 2024 ▾] ◄── Selecciona mes                │
│                                                             │
│ ⏳ Cargando datos...                                       │
│ → GET /reports?period=monthly&date=2024-03                 │
│          │                                                  │
│          ▼                                                  │
│ ╔═══════════════════════════════════════╗                  │
│ ║ 📈 Ingresos  📉 Gastos  💰 Balance   ║                  │
│ ║  $15,500      $8,420     +$7,080     ║                  │
│ ║  +8.3% ↑      -5.2% ↓    +15.2% ↑    ║                  │
│ ╚═══════════════════════════════════════╝                  │
│                                                             │
│ ┌──────────────────────────────────────┐                   │
│ │ Ingresos vs Gastos                   │                   │
│ │                                      │                   │
│ │      [GRÁFICO DE BARRAS]             │                   │
│ │                                      │                   │
│ │ Marzo: ████ Ingresos                 │                   │
│ │        ██   Gastos                   │                   │
│ └──────────────────────────────────────┘                   │
│                                                             │
│ ┌──────────────────────────────────────┐                   │
│ │ Top Categorías de Gasto              │                   │
│ │                                      │                   │
│ │ 1. 🍔 Comida        $2,340 (28%)    │                   │
│ │ 2. 🏠 Vivienda      $1,800 (21%)    │                   │
│ │ 3. 🚗 Transporte    $1,120 (13%)    │                   │
│ │ 4. 💡 Servicios       $875 (10%)    │                   │
│ │ 5. 🎬 Entretenimient  $540  (6%)    │                   │
│ └──────────────────────────────────────┘                   │
│                                                             │
│ ┌──────────────────────────────────────┐                   │
│ │ Insights & Recomendaciones           │                   │
│ │                                      │                   │
│ │ 💡 Gastaste 5% menos que el mes      │                   │
│ │    anterior. ¡Buen trabajo!          │                   │
│ │                                      │                   │
│ │ ⚠️  Tu categoría de Comida está     │                   │
│ │    28% por encima del promedio.      │                   │
│ │    Considera reducir gastos.         │                   │
│ │                                      │                   │
│ │ ✅ Tu tasa de ahorro es del 45.7%   │                   │
│ │    ¡Excelente!                       │                   │
│ └──────────────────────────────────────┘                   │
│                                                             │
│ [📥 Exportar PDF] ◄── Click para descargar                │
│          │                                                  │
│          ▼                                                  │
│ ⏳ Generando PDF...                                        │
│ ✅ Descargado: reporte-marzo-2024.pdf                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 6️⃣ FLUJO DE CONFIGURACIÓN

### Cambiar Plan
```
┌─────────────────────────────────────────────────────────────┐
│ Sidebar → [Upgrade to Pro] ◄── Click                       │
│          │                                                  │
│          ▼                                                  │
│ Navega a: Settings (Configuración)                         │
│ Tab activa: Plan y Facturación                             │
│                                                             │
│ ┌─────────────────────────────────────────────────────────┐│
│ │ PLANES DISPONIBLES                                      ││
│ │                                                         ││
│ │ ┌──────────┐  ┌──────────┐  ┌──────────┐              ││
│ │ │ Free     │  │ Premium  │  │ Pro      │              ││
│ │ │          │  │    ✓     │  │          │              ││
│ │ │ $0/mes   │  │ $9.99/mes│  │ $19.99mes│              ││
│ │ │          │  │          │  │          │              ││
│ │ │ • 10     │  │ • Ilimitado│ │ • Todo  │              ││
│ │ │   transc.│  │ • Reportes │ │   Premium│              ││
│ │ │ • 3 presu│  │ • Alertas  │ │ • Soporte│              ││
│ │ │ • 1 meta │  │ • Export   │ │ • Multi- │              ││
│ │ │          │  │            │ │   moneda │              ││
│ │ │ [Actual] │  │ [MEJORAR]  │ │ [MEJORAR]│              ││
│ │ └──────────┘  └──────────┘  └──────────┘              ││
│ │                     ▲                                   ││
│ │                     │                                   ││
│ └─────────────────────┼─────────────────────────────────┘│
│                       │                                    │
│ Click en [MEJORAR]  ◄─┘                                   │
│          │                                                 │
│          ▼                                                 │
│ ┌────────────────────────────────────┐                    │
│ │ Confirmar actualización            │                    │
│ │                                    │                    │
│ │ Cambiar a: Premium                 │                    │
│ │ Costo: $9.99/mes                   │                    │
│ │                                    │                    │
│ │ Método de pago:                    │                    │
│ │ 💳 Tarjeta: •••• 4242              │                    │
│ │                                    │                    │
│ │ Próximo cargo: 15 Abril 2024       │                    │
│ │                                    │                    │
│ │ [Cancelar] [Confirmar]             │                    │
│ └────────────────────────────────────┘                    │
│          │                                                 │
│          ▼                                                 │
│ ⏳ Procesando pago...                                     │
│ → PUT /user { plan: 'premium' }                           │
│          │                                                 │
│          ▼                                                 │
│ ✅ Plan actualizado                                       │
│ 🎉 "¡Bienvenido a Premium!"                               │
│                                                            │
│ Nuevas características desbloqueadas:                      │
│ • ✨ Presupuestos ilimitados                              │
│ • ✨ Reportes avanzados                                   │
│ • ✨ Alertas personalizadas                               │
│ • ✨ Exportar a PDF                                       │
│                                                            │
└─────────────────────────────────────────────────────────────┘
```

---

## 7️⃣ FLUJO DE NOTIFICACIONES

```
┌─────────────────────────────────────────────────────────────┐
│ SISTEMA DE NOTIFICACIONES                                   │
│                                                             │
│ Evento: Usuario alcanza 80% del presupuesto de Comida      │
│          │                                                  │
│          ▼                                                  │
│ Sistema detecta: spent/limit >= 0.8                        │
│          │                                                  │
│          ▼                                                  │
│ Crea notificación:                                          │
│ {                                                           │
│   type: 'warning',                                         │
│   title: 'Presupuesto casi excedido',                     │
│   message: 'Has gastado el 80% de tu presupuesto de       │
│             Comida',                                       │
│   timestamp: now(),                                        │
│   unread: true                                            │
│ }                                                           │
│          │                                                  │
│          ▼                                                  │
│ Muestra en Header:                                          │
│ [🔔³] ◄── Badge con contador                              │
│    │                                                        │
│    │ Usuario hace click                                    │
│    ▼                                                        │
│ Abre panel de notificaciones                               │
│                                                             │
│ ┌──────────────────────────────────┐                       │
│ │ Notificaciones             [✕]   │                       │
│ ├──────────────────────────────────┤                       │
│ │ ● Presupuesto casi excedido      │                       │
│ │   Has gastado el 80% de tu       │                       │
│ │   presupuesto de Comida          │                       │
│ │   Hace 2 horas                   │                       │
│ │                                  │                       │
│ │ ● Nueva transacción              │                       │
│ │   Se registró un ingreso de $500 │                       │
│ │   Hace 5 horas                   │                       │
│ │                                  │                       │
│ │ ● Meta alcanzada                 │                       │
│ │   ¡Completaste tu meta de        │                       │
│ │   Vacaciones!                    │                       │
│ │   Hace 1 día                     │                       │
│ └──────────────────────────────────┘                       │
│                                                             │
│ Click en notificación                                       │
│ → Marca como leída                                         │
│ → Navega a página relevante                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 8️⃣ FLUJO DE ERROR Y RECUPERACIÓN

### Error de Red → Modo Demo
```
┌─────────────────────────────────────────────────────────────┐
│ Usuario intenta cargar Dashboard                            │
│          │                                                  │
│          ▼                                                  │
│ → GET /transactions                                         │
│          │                                                  │
│          ▼                                                  │
│ ❌ NetworkError: Failed to fetch                           │
│          │                                                  │
│          ▼                                                  │
│ API detecta error de red                                    │
│ → catch (error)                                            │
│ → if (error.name === 'NetworkError')                       │
│          │                                                  │
│          ▼                                                  │
│ Activa modo demo:                                           │
│ → setDemoMode(true)                                        │
│ → return MOCK_DATA                                         │
│          │                                                  │
│          ▼                                                  │
│ ╔═════════════════════════════════════════════════════════╗│
│ ║ ⚠️ Modo Demo - Los datos son de prueba                 ║│
│ ║ El backend no está disponible. Funcionalidad limitada. ║│
│ ╚═════════════════════════════════════════════════════════╝│
│                                                             │
│ Dashboard se carga con datos de ejemplo                     │
│ Usuario puede:                                              │
│ ✅ Ver todas las páginas                                   │
│ ✅ Ver gráficos y reportes                                 │
│ ✅ Navegar entre secciones                                 │
│ ❌ No puede crear/editar/eliminar                          │
│                                                             │
│ Si intenta crear transacción:                               │
│ 🔔 "Modo demo activo. Conecta el backend para guardar."   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 MÉTRICAS DE ÉXITO

### Registro y Onboarding
- ✅ Usuario registrado en < 30 segundos
- ✅ Primera transacción creada en < 2 minutos
- ✅ Dashboard completo visible inmediatamente

### Uso Diario
- ✅ Crear transacción en < 10 segundos
- ✅ Ver reportes en < 3 segundos
- ✅ Recibir alertas en tiempo real

### Satisfacción
- ✅ Interfaz intuitiva (no requiere tutorial)
- ✅ Respuestas rápidas (< 500ms)
- ✅ Sin errores visibles al usuario

---

**Flujo:** Optimizado para productividad  
**Accesibilidad:** WCAG 2.1 AA  
**Performance:** < 3s tiempo de carga  
**Versión:** 1.0
