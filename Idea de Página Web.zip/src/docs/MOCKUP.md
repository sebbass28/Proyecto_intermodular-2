# FinanceFlow - Mockup Visual Completo

## 🎨 GUÍA DE DISEÑO

### Paleta de Colores

#### Colores Principales
```
Primary Blue:      #2563eb  (rgb(37, 99, 235))
Primary Purple:    #9333ea  (rgb(147, 51, 234))
Gradient:          from-blue-600 to-purple-600

Success Green:     #10b981  (rgb(16, 185, 129))
Warning Yellow:    #f59e0b  (rgb(245, 158, 11))
Error Red:         #ef4444  (rgb(239, 68, 68))
```

#### Colores de Fondo
```
Background Light:  #f8fafc  (from-blue-50 to-purple-50)
White:             #ffffff
Gray 50:           #f9fafb
Gray 100:          #f3f4f6
Gray 200:          #e5e7eb
```

#### Colores de Texto
```
Text Primary:      #111827  (gray-900)
Text Secondary:    #6b7280  (gray-500)
Text Light:        #9ca3af  (gray-400)
```

### Tipografía

```
Font Family:       Inter, system-ui, sans-serif
Headings:          font-bold
Body:              font-normal
Small:             font-normal text-sm

Sizes:
- text-xs:   0.75rem (12px)
- text-sm:   0.875rem (14px)
- text-base: 1rem (16px)
- text-lg:   1.125rem (18px)
- text-xl:   1.25rem (20px)
- text-2xl:  1.5rem (24px)
- text-3xl:  1.875rem (30px)
```

### Espaciado

```
Padding Cards:     p-6 (1.5rem / 24px)
Gap Elements:      gap-4 (1rem / 16px)
Margin Bottom:     mb-6 (1.5rem / 24px)
Border Radius:     rounded-lg (0.5rem / 8px)
                   rounded-xl (0.75rem / 12px)
                   rounded-2xl (1rem / 16px)
```

### Sombras

```
shadow-sm:         0 1px 2px 0 rgb(0 0 0 / 0.05)
shadow-md:         0 4px 6px -1px rgb(0 0 0 / 0.1)
shadow-lg:         0 10px 15px -3px rgb(0 0 0 / 0.1)
shadow-xl:         0 20px 25px -5px rgb(0 0 0 / 0.1)
```

---

## 🎨 PÁGINA DE LOGIN (Mockup Visual)

```
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║                    Fondo degradado azul-morado                ║
║              background: linear-gradient(135deg,              ║
║                   from-blue-600 to-purple-600)                ║
║                                                               ║
║     ┌───────────────────────────────────────────────┐        ║
║     │  bg-white rounded-2xl shadow-2xl p-8          │        ║
║     │  max-w-md                                      │        ║
║     │                                                │        ║
║     │       ┌────┐                                   │        ║
║     │       │ 🔵 │  FinanceFlow                      │        ║
║     │       └────┘  (Logo degradado)                 │        ║
║     │                                                │        ║
║     │       Bienvenido de vuelta                     │        ║
║     │       (text-2xl font-bold)                     │        ║
║     │                                                │        ║
║     │       Inicia sesión en tu cuenta               │        ║
║     │       (text-gray-600 text-sm)                  │        ║
║     │                                                │        ║
║     │  ┌──────────────────────────────────────┐     │        ║
║     │  │ 📧 Email                             │     │        ║
║     │  │ bg-gray-50 border-gray-200           │     │        ║
║     │  └──────────────────────────────────────┘     │        ║
║     │                                                │        ║
║     │  ┌──────────────────────────────────────┐     │        ║
║     │  │ 🔒 Contraseña                        │     │        ║
║     │  │ bg-gray-50 border-gray-200           │     │        ║
║     │  └──────────────────────────────────────┘     │        ║
║     │                                                │        ║
║     │  ☑ Recordarme    ¿Olvidaste tu contraseña?   │        ║
║     │  (text-sm text-blue-600)                      │        ║
║     │                                                │        ║
║     │  ┌──────────────────────────────────────┐     │        ║
║     │  │      INICIAR SESIÓN                  │     │        ║
║     │  │  bg-gradient-to-r from-blue-600      │     │        ║
║     │  │  to-purple-600 text-white            │     │        ║
║     │  │  shadow-lg hover:shadow-xl           │     │        ║
║     │  └──────────────────────────────────────┘     │        ║
║     │                                                │        ║
║     │         ──────── o ────────                    │        ║
║     │                                                │        ║
║     │  ┌──────────────────────────────────────┐     │        ║
║     │  │  🔵 Continuar con Google             │     │        ║
║     │  │  bg-white border-gray-300            │     │        ║
║     │  └──────────────────────────────────────┘     │        ║
║     │                                                │        ║
║     │  ¿No tienes cuenta? Regístrate aquí           │        ║
║     │  (text-sm text-center text-blue-600)          │        ║
║     │                                                │        ║
║     └────────────────────────────────────────────────┘        ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝

Colores específicos:
- Fondo exterior: Degradado azul-morado (#2563eb → #9333ea)
- Card principal: Blanco (#ffffff) con sombra 2xl
- Botón principal: Degradado azul-morado con sombra
- Inputs: Gris claro (#f9fafb) con borde gris (#e5e7eb)
- Enlaces: Azul (#2563eb)
```

---

## 🎨 DASHBOARD (Mockup Visual)

```
╔═════════════════════════════════════════════════════════════════════════════╗
║ HEADER (bg-white/95 backdrop-blur border-b h-16)                            ║
║ ┌──────────┐              ┌──────────────┐        ┌─────────────────────┐  ║
║ │ [F] Logo │              │ 🔍 Buscar... │        │ 🔔³ ⚙️ [👤 Usuario] │  ║
║ └──────────┘              └──────────────┘        └─────────────────────┘  ║
╠═════════════════════════════════════════════════════════════════════════════╣
║ S │                                                                          ║
║ I │ Dashboard                                    📅 Marzo 2024               ║
║ D │ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━║
║ E │                                                                          ║
║ B │ ┏━━━━━━━━━━━━━┓ ┏━━━━━━━━━━━━━┓ ┏━━━━━━━━━━━━��┓ ┏━━━━━━━━━━━━━┓      ║
║ A │ ┃ 💰 Balance  ┃ ┃ 📈 Ingresos ┃ ┃ 📉 Gastos   ┃ ┃ 💳 Ahorros  ┃      ║
║ R │ ┃             ┃ ┃             ┃ ┃             ┃ ┃             ┃      ║
║   │ ┃  $45,320    ┃ ┃  $15,500    ┃ ┃  $8,420     ┃ ┃  $12,300    ┃      ║
║ + │ ┃ (text-3xl)  ┃ ┃ (text-3xl)  ┃ ┃ (text-3xl)  ┃ ┃ (text-3xl)  ┃      ║
║ N │ ┃             ┃ ┃             ┃ ┃             ┃ ┃             ┃      ║
║ u │ ┃  +12.5% ↑   ┃ ┃  +8.3% ↑    ┃ ┃  -5.2% ↓    ┃ ┃  +15% ↑     ┃      ║
║ e │ ┃ (text-green)┃ ┃ (text-green)┃ ┃ (text-red)  ┃ ┃ (text-green)┃      ║
║ v │ ┗━━━━━━━━━━━━━┛ ┗━━━━━━━━━━━━━┛ ┗━━━━━━━━━━━━━┛ ┗━━━━━━━━━━━━━┛      ║
║ a │ (Cards: bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-500)  ║
║   │                                                                          ║
║ T │ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓    ║
║ r │ ┃ Resumen Financiero            ┃ ┃ Transacciones Recientes       ┃    ║
║ a │ ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫ ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫    ║
║ n │ ┃                               ┃ ┃                               ┃    ║
║ s │ ┃    ╱╲    ╱╲     ╱╲           ┃ ┃ 🍔 Comida      -$45.00   Hoy  ┃    ║
║ . │ ┃   ╱  ╲  ╱  ╲   ╱  ╲          ┃ ┃ (text-sm text-gray-600)       ┃    ║
║   │ ┃  ╱    ╲╱    ╲ ╱    ╲         ┃ ┃                               ┃    ║
║ D │ ┃ ╱            ╲      ╲        ┃ ┃ 💼 Salario   +$3,500   Ayer   ┃    ║
║ a │ ┃ Balance mensual (Recharts)    ┃ ┃ (text-sm text-green-600)      ┃    ║
║ s │ ┃ (Gráfico de líneas azul)      ┃ ┃                               ┃    ║
║ h │ ┃                               ┃ ┃ 🚗 Transporte  -$20.00    2d  ┃    ║
║ b │ ┃                               ┃ ┃                               ┃    ║
║ o │ ┃ Ene  Feb  Mar  Abr  May  Jun  ┃ ┃ 🎬 Netflix     -$12.99    3d  ┃    ║
║ a │ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ ┃                               ┃    ║
║ r │                                   ┃ 💡 Electricidad -$85.00   5d  ┃    ║
║ d │                                   ┃                               ┃    ║
║   │                                   ┃      Ver todas →              ┃    ║
║ T │ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ ┃ (text-blue-600 hover:underline)┃   ║
║ r │ ┃ Distribución de Gastos        ┃ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛    ║
║ a │ ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫                                     ║
║ n │ ┃                               ┃ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓    ║
║ s │ ┃         ╭───────╮             ┃ ┃ Presupuestos                  ┃    ║
║ . │ ┃       ╱           ╲           ┃ ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫    ║
║   │ ┃      │      ●      │          ┃ ┃                               ┃    ║
║ P │ ┃      │             │          ┃ ┃ 🍔 Comida                     ┃    ║
║ r │ ┃       ╲           ╱           ┃ ┃ [████████████████░░░░] 80%    ┃    ║
║ e │ ┃         ╰───────╯             ┃ ┃ $400 / $500                   ┃    ║
║ s │ ┃  (Dona Chart - Recharts)      ┃ ┃ (bg-blue-100 h-2 rounded)     ┃    ║
║ u │ ┃                               ┃ ┃                               ┃    ║
║ p │ ┃ 🍔 Comida       35%           ┃ ┃ 🚗 Transporte                 ┃    ║
║ . │ ┃ 🚗 Transporte   20%           ┃ ┃ [████████░░░░░░░░] 40%        ┃    ║
║   │ ┃ 🎬 Entretenim.  15%           ┃ ┃ $120 / $300                   ┃    ║
║ I │ ┃ 💡 Servicios    12%           ┃ ┃                               ┃    ║
║ n │ ┃ 🛍️ Compras      10%           ┃ ┃ 🎬 Entretenimiento            ┃    ║
║ v │ ┃ 📦 Otros         8%           ┃ ┃ [█████░░░░░░░░░░] 25%         ┃    ║
║ . │ ┃                               ┃ ┃ $50 / $200                    ┃    ║
║   │ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛    ║
║ M │ (Cards: bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition)  ║
║ e │                                                                          ║
║ t │                                                                          ║
║ a │                                                                          ║
║ s │                                                                          ║
║   │                                                                          ║
║ R │                                                                          ║
║ e │                                                                          ║
║ p │                                                                          ║
║ o │                                                                          ║
║ r │                                                                          ║
║ t │                                                                          ║
║ . │                                                                          ║
║   │                                                                          ║
║ P │                                                                          ║
║ e │                                                                          ║
║ r │                                                                          ║
║ f │                                                                          ║
║ . │                                                                          ║
║   │                                                                          ║
║ C │                                                                          ║
║ o │                                                                          ║
║ n │                                                                          ║
║ f │                                                                          ║
║ . │                                                                          ║
║   │                                                                          ║
║ ━ │                                                                          ║
║   │                                                                          ║
║ U │                                                                          ║
║ p │                                                                          ║
║ g │                                                                          ║
║ r │                                                                          ║
║ a │                                                                          ║
║ d │                                                                          ║
║ e │                                                                          ║
╚═════════════════════════════════════════════════════════════════════════════╝

Especificaciones visuales:
- Header: Fondo blanco semitransparente con blur, altura 64px
- Sidebar: Ancho 256px, fondo blanco con sombra
- Cards de métricas: Borde izquierdo de 4px en color del indicador
- Gráficos: Colores degradados azul-morado
- Hover effects: Escala 1.02 y sombra aumentada
- Animaciones: motion/react con duración 0.3s
```

---

## 🎨 MODAL NUEVA TRANSACCIÓN (Mockup Visual)

```
╔═════════════════════════════════════════════════════════════════╗
║                                                                 ║
║              Fondo semi-transparente (backdrop)                 ║
║                bg-black/50 backdrop-blur-sm                     ║
║                                                                 ║
║    ┌────────────────────────────────────────────────────┐      ║
║    │  bg-white rounded-2xl shadow-2xl max-w-lg         │      ║
║    │                                                    │      ║
║    │  ┌──────────────────────────────────────────┐     │      ║
║    │  │ 💰 Nueva Transacción          [✕]       │     │      ║
║    │  │ (bg-white sticky top-0)                  │     │      ║
║    │  │ Registra un nuevo ingreso o gasto        │     │      ║
║    │  └──────────────────────────────────────────┘     │      ║
║    │                                                    │      ║
║    │  Tipo de Transacción *                             │      ║
║    │  (text-sm font-medium)                             │      ║
║    │                                                    │      ║
║    │  ┌──────────────┐  ┌──────────────┐              │      ║
║    │  │  💸 Gasto    │  │  💰 Ingreso  │              │      ║
║    │  │  [SELECTED]  │  │              │              │      ║
║    │  │ border-red-  │  │ border-gray- │              │      ║
║    │  │ 500 bg-red-  │  │ 200          │              │      ║
║    │  │ 50           │  │              │              │      ║
║    │  └──────────────┘  └──────────────┘              │      ║
║    │  (p-4 rounded-lg border-2 transition-all)         │      ║
║    │                                                    │      ║
║    │  Monto *                                           │      ║
║    │  ┌──────────────────────────────────────────┐     │      ║
║    │  │ $ 0.00                                   │     │      ║
║    │  │ (text-lg)                                │     │      ║
║    │  └──────────────────────────────────────────┘     │      ║
║    │                                                    │      ║
║    │  Categoría *                                       │      ║
║    │  ┌──────────────────────────────────────────┐     │      ║
║    │  │ Selecciona una categoría       [▾]      │     │      ║
║    │  └──────────────────────────────────────────┘     │      ║
║    │  (Select component con iconos)                    │      ║
║    │                                                    │      ║
║    │  Descripción                                       │      ║
║    │  ┌──────────────────────────────────────────┐     │      ║
║    │  │ Agrega detalles sobre esta              │     │      ║
║    │  │ transacción...                           │     │      ║
║    │  │                                          │     │      ║
║    │  └──────────────────────────────────────────┘     │      ║
║    │  (Textarea rows-3 resize-none)                    │      ║
║    │                                                    │      ║
║    │  Fecha *                                           │      ║
║    │  ┌──────────────────────────────────────────┐     │      ║
║    │  │ 2024-03-15                   [📅]        │     │      ║
║    │  └──────────────────────────────────────────┘     │      ║
║    │                                                    │      ║
║    │  ┌──────────────┐  ┌────────────────────────┐    │      ║
║    │  │  Cancelar    │  │  Crear Transacción     │    │      ║
║    │  │  (outline)   │  │  (gradient blue-purple)│    │      ║
║    │  └──────────────┘  └────────────────────────┘    │      ║
║    │                                                    │      ║
║    └────────────────────────────────────────────────────┘      ║
║                                                                 ║
╚═════════════════════════════════════════════════════════════════╝

Animaciones:
- Initial: opacity: 0, scale: 0.95, y: 20
- Animate: opacity: 1, scale: 1, y: 0
- Exit: opacity: 0, scale: 0.95, y: 20
- Duration: 0.2s
```

---

## 🎨 PANEL DE NOTIFICACIONES (Mockup Visual)

```
┌───────────────────────────────────────────┐
│ Notificaciones                       [✕]  │
│ (font-semibold text-lg)                   │
├───────────────────────────────────────────┤
│                                           │
│ ┌───────────────────────────────────────┐ │
│ │ ● Presupuesto casi excedido           │ │
│ │ (bg-blue-50/50)                       │ │
│ │ Has gastado el 90% de tu presupuesto  │ │
│ │ de Comida                             │ │
│ │ (text-xs text-gray-600)               │ │
│ │ Hace 2 horas                          │ │
│ │ (text-xs text-gray-400)               │ │
│ └───────────────────────────────────────┘ │
│ (hover:bg-gray-50 cursor-pointer)         │
│                                           │
│ ┌───────────────────────────────────────┐ │
│ │ ● Nueva transacción                   │ │
│ │ (bg-blue-50/50)                       │ │
│ │ Se registró un ingreso de $500        │ │
│ │ Hace 5 horas                          │ │
│ └───────────────────────────────────────┘ │
│                                           │
│ ┌───────────────────────────────────────┐ │
│ │ ● Meta alcanzada                      │ │
│ │ (bg-blue-50/50)                       │ │
│ │ ¡Felicidades! Completaste tu meta     │ │
│ │ de Vacaciones                         │ │
│ │ Hace 1 día                            │ │
│ └───────────────────────────────────────┘ │
│                                           │
│ ┌───────────────────────────────────────┐ │
│ │ ○ Recordatorio                        │ │
│ │ (no unread)                           │ │
│ │ No olvides registrar tus gastos       │ │
│ │ Hace 2 días                           │ │
│ └───────────────────────────────────────┘ │
│                                           │
├───────────────────────────────────────────┤
│     Ver todas las notificaciones          │
│     (text-blue-600 text-sm)               │
└───────────────────────────────────────────┘

Especificaciones:
- Ancho: 384px (w-96)
- Posición: absolute top-full right-0 mt-2
- Fondo: bg-white rounded-lg shadow-xl
- Altura máxima: max-h-96 overflow-y-auto
- Indicadores: w-2 h-2 rounded-full
  - Warning: bg-yellow-500
  - Success: bg-green-500
  - Info: bg-blue-500
```

---

## 🎨 COMPONENTES UI DETALLADOS

### Botón Principal (Primary Button)
```
┌──────────────────────────────────────┐
│        TEXTO DEL BOTÓN               │
│                                      │
│  bg-gradient-to-r from-blue-600     │
│  to-purple-600                       │
│  text-white                          │
│  px-6 py-3                           │
│  rounded-lg                          │
│  shadow-lg hover:shadow-xl           │
│  transition-all duration-200         │
│  hover:scale-105                     │
└──────────────────────────────────────┘
```

### Card Básica
```
┌──────────────────────────────────────┐
│  Título de la Card                   │
│  (font-semibold text-lg)             │
├──────────────────────────────────────┤
│                                      │
│  Contenido de la card                │
│  (text-sm text-gray-600)             │
│                                      │
│  bg-white                            │
│  rounded-xl                          │
│  shadow-md                           │
│  p-6                                 │
│  hover:shadow-lg                     │
│  transition-shadow                   │
│                                      │
└──────────────────────────────────────┘
```

### Card de Métrica
```
┌──────────────────────────────────────┐
│┃ 💰 Balance Total                    │
│┃ (border-l-4 border-blue-500)        │
│┃                                     │
│┃ $45,320                             │
│┃ (text-3xl font-bold)                │
│┃                                     │
│┃ +12.5% ↑                            │
│┃ (text-green-600 text-sm)            │
│┃                                     │
│┃ bg-white                            │
│┃ rounded-xl                          │
│┃ shadow-md                           │
│┃ p-6                                 │
└──────────────────────────────────────┘
```

### Input Field
```
┌──────────────────────────────────────┐
│ 📧 Placeholder text...               │
│                                      │
│ bg-gray-50/50                        │
│ border border-gray-200               │
│ rounded-lg                           │
│ px-4 py-2                            │
│ focus:bg-white                       │
│ focus:border-blue-500                │
│ focus:ring-2 focus:ring-blue-100     │
│ transition-all                       │
└──────────────────────────────────────┘
```

### Progress Bar
```
Comida: $400 / $500 (80%)

┌──────────────────────────────────────┐
│████████████████░░░░                  │
└──────────────────────────────────────┘

Estructura:
<div class="w-full bg-gray-200 rounded-full h-2">
  <div class="bg-gradient-to-r from-blue-600 
       to-purple-600 h-2 rounded-full" 
       style="width: 80%">
  </div>
</div>

Estados:
- < 50%: bg-green-500
- 50-80%: bg-yellow-500
- > 80%: bg-red-500
```

### Badge
```
┌─────┐  ┌──────────┐  ┌───────┐  ┌─────────┐
│  3  │  │ Premium  │  │ Nuevo │  │ +12.5%  │
└─────┘  └──────────┘  └───────┘  └─────────┘

Variantes:
- Notification: bg-red-500 text-white
- Status: bg-blue-100 text-blue-800
- Success: bg-green-100 text-green-800
- Warning: bg-yellow-100 text-yellow-800

Clases:
rounded-full px-2 py-1 text-xs font-medium
```

### Select Dropdown
```
┌──────────────────────────────────────┐
│ Selecciona una opción       [▾]      │
└──────────────────────────────────────┘

Al abrir:
┌──────────────────────────────────────┐
│ Selecciona una opción       [▾]      │
└──────────────────────────────────────┘
  ┌────────────────────────────────────┐
  │ 🍔 Comida                          │
  │ 🚗 Transporte                      │
  │ 🎬 Entretenimiento                 │
  │ 💡 Servicios                       │
  └────────────────────────────────────┘
  
  bg-white
  rounded-lg
  shadow-lg
  border border-gray-200
  max-h-60 overflow-y-auto
```

---

## 🎨 ESTADOS INTERACTIVOS

### Hover States
```
Botones:
- scale: 1.05
- shadow: increased
- brightness: 110%

Cards:
- shadow: md → lg
- translate-y: -2px

Links:
- color: blue-600 → blue-700
- underline
```

### Active States
```
Botones:
- scale: 0.95
- shadow: decreased

Tabs:
- border-b-2 border-blue-600
- text-blue-600
- bg-blue-50
```

### Focus States
```
Inputs:
- border-color: blue-500
- ring-2 ring-blue-100
- bg-white

Botones:
- ring-2 ring-blue-300
- ring-offset-2
```

### Loading States
```
Botones:
┌──────────────────────────────────────┐
│  ⟳ Cargando...                       │
│  (spinner animation)                 │
│  opacity-75                          │
│  cursor-not-allowed                  │
└──────────────────────────────────────┘

Skeleton Screens:
┌──────────────────────────────────────┐
│ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░       │
│ ░░░░░░░░░░░░░░░░░                    │
│                                      │
│ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░   │
│                                      │
│ bg-gray-200 animate-pulse            │
└──────────────────────────────────────┘
```

---

## 🎨 DISEÑO RESPONSIVO

### Desktop (>= 1440px)
```
- Sidebar: 256px fixed
- Main content: flexible
- Cards en grid: 4 columnas
- Gráficos: altura completa
```

### Tablet (768px - 1439px)
```
- Sidebar: 200px fixed
- Main content: flexible
- Cards en grid: 2 columnas
- Gráficos: altura media
```

### Mobile (< 768px)
```
- Sidebar: oculto (hamburger menu)
- Main content: full width
- Cards en grid: 1 columna
- Bottom navigation: 60px
- Padding reducido: p-4
```

---

## 🎨 ANIMACIONES CON MOTION/REACT

### Page Transitions
```javascript
initial={{ opacity: 0, y: 20 }}
animate={{ opacity: 1, y: 0 }}
exit={{ opacity: 0, y: -20 }}
transition={{ duration: 0.3 }}
```

### Modal Animations
```javascript
initial={{ opacity: 0, scale: 0.95 }}
animate={{ opacity: 1, scale: 1 }}
exit={{ opacity: 0, scale: 0.95 }}
```

### Card Hover
```javascript
whileHover={{ scale: 1.02, y: -4 }}
whileTap={{ scale: 0.98 }}
```

### Button Interactions
```javascript
whileHover={{ scale: 1.05 }}
whileTap={{ scale: 0.95 }}
transition={{ type: "spring", stiffness: 400 }}
```

---

## 🎨 ICONOGRAFÍA

### Lucide React Icons
```
- DollarSign: Transacciones, monedas
- TrendingUp: Ingresos, crecimiento
- TrendingDown: Gastos, disminución
- Wallet: Carteras
- Target: Metas
- BarChart3: Reportes
- CreditCard: Tarjetas
- Bell: Notificaciones
- Search: Búsqueda
- Settings: Configuración
- User: Perfil
- PlusCircle: Agregar
- X: Cerrar
- Check: Confirmar
- AlertCircle: Alertas
- Info: Información
```

### Emojis para Categorías
```
🍔 Comida
🚗 Transporte
🎬 Entretenimiento
💡 Servicios
🏥 Salud
📚 Educación
🛍️ Compras
📦 Otros
💼 Salario
💻 Freelance
📈 Inversiones
```

---

## 🎨 GRÁFICOS (RECHARTS)

### Line Chart (Resumen Financiero)
```
Colores:
- Línea principal: #2563eb (blue-600)
- Área bajo la línea: rgba(37, 99, 235, 0.1)
- Grid: #e5e7eb (gray-200)
- Tooltip: bg-white shadow-lg rounded-lg
```

### Donut Chart (Distribución)
```
Colores por categoría:
- Comida: #ef4444 (red-500)
- Transporte: #3b82f6 (blue-500)
- Entretenimiento: #8b5cf6 (purple-500)
- Servicios: #10b981 (green-500)
- Compras: #f59e0b (yellow-500)
- Otros: #6b7280 (gray-500)
```

### Bar Chart (Comparativas)
```
Colores:
- Ingresos: #10b981 (green-500)
- Gastos: #ef4444 (red-500)
- Grid: #e5e7eb (gray-200)
```

---

## 🎨 MODO DEMO BANNER

```
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║  ⚠️ Modo Demo - Los datos son de prueba                      ║
║  (bg-yellow-50 border-l-4 border-yellow-500 text-yellow-800) ║
║  El backend no está disponible. Funcionalidad limitada.      ║
║                                         [Conectar backend →]  ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝

Posición: sticky top-16 z-30
Padding: p-4
```

---

## ✅ CHECKLIST DE DISEÑO

- ✅ Paleta de colores consistente
- ✅ Tipografía jerárquica
- ✅ Espaciado uniforme
- ✅ Sombras para profundidad
- ✅ Bordes redondeados
- ✅ Degradados sutiles
- ✅ Hover states definidos
- ✅ Animaciones fluidas
- ✅ Iconos consistentes
- ✅ Responsive en 3 breakpoints
- ✅ Accesibilidad (contraste)
- ✅ Loading states
- ✅ Empty states
- ✅ Error states

---

**Diseño:** Premium & Moderno  
**Framework:** React + Tailwind CSS  
**Animaciones:** Motion/React  
**Gráficos:** Recharts  
**Iconos:** Lucide React  
**Versión:** 1.0
