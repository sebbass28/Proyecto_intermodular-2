
  # Idea de Página Web

  This is a code bundle for Idea de Página Web. The original project is available at https://www.figma.com/design/c9EUi0lItjgG0F0JJW8qcg/Idea-de-P%C3%A1gina-Web.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  